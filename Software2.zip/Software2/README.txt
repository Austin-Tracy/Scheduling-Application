Title: Scheduling Application
Purpose: Scheduling Application that allows CRUD operations for Customers and Appointments
Author: Austin Tracy
Contact Information: Austin Tracy - Email: atrac24@my.wgu.edu
Student Application Version: 4.0
Date: 6/20/2022
IDE: Apache NetBeans IDE 13
JDK: Java SE 18.0.1
JavaFX: JavaFX-SDK-18.0.1
MySQL Connector: mysql-connector-java-8.0.29

How to Use: After Initializing the Application, Enter your UserName and Password
before selecting Log In. Incorrect credentials or null values will be rejected.
After successfully logging in you will be redirected to the Scheduling Hub, here
you can toggle through the three reporting options.  Report one will return the
number of a given Type within a user specified month.  The Seconds will return 
a chosen contacts full schedule. The third is a Pie Chart that tallies failed 
login attempts vs. successful for a colorful display. The Customer Button
redirects to the customer interface, where customers can be Viewed, Updated,
Created or Deleted.  The Appointments Button will redirect to the Appointment
Interface where appointments can be Viewed, Updated, Created or Deleted.  In
the tableview start and end times are shown in UTC, but when creating or updating
the start time and end time are shown in Local Time.  To Create a new customer 
fill out all of the form fields and select New Appointment.  To Modify existing
Appointment, select modify to move the data to the editable fields before
selecting save to update the view and DB.

Custom Report: For my custom report, i chose to include a Pie Chart for Successful
Login Attempts compared to Failed login Attempts. Both Null Entries and incorrect
credentials are considered a Failed Attempt.

JavaDocs: ~Software2\dist\javadoc\index.html